from .rubiks_cube import Cube, scramble_generator
