# RubiksCube
Implementation of a Rubiks Cube in python.
